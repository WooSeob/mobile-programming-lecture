require("../app_server/models/db");
const mongoose = require("mongoose");
const db = mongoose.connection;
const Location = require("../app_server/models/locations");
const lib = require("./lib");

//입력 관리
const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.setPrompt(">");
console.log(
  "명령어 입력\n1. Locations모두 삭제 \n2. 랜덤 Locations생성 \n3. 종료"
);
rl.prompt();
rl.on("line", (input) => {
  if (input === "1") {
    removeAll();
  } else if (input === "2") {
    generateData();
  } else if (input === "3") {
    rl.close();
  }
  rl.prompt();
});
rl.on("close", () => {
  process.exit();
});

async function removeAll() {
  await db.dropCollection("locations", (err, result) => {
    console.log("모두 삭제 완료");
  });
}

async function generateData() {
  new Location(prefixSample).save();

  for (let i = 0; i < 9; i++) {
    var locationData = lib.generateLocationData();
    console.log(locationData);

    let newLocation = await new Location(locationData);
    await newLocation.save();
  }
}

const prefixSample = {
  name: "Starcups",
  address: "서울특별시 관악구 호암로 100",
  rating: 3,
  facilities: ["Hot drinks", "Food", "Premium wifi"],
  coords: [127.0111, 37.3666],
  openingTimes: [
    {
      days: "Monday - Friday",
      opening: "7:00am",
      closing: "7:00pm",
      closed: false,
    },
    {
      days: "Saturday",
      opening: "8:00am",
      closing: "5:00pm",
      closed: false,
    },
    {
      days: "Sunday",
      closed: true,
    },
  ],
  reviews: [
    {
      author: "Samkeun Kim",
      rating: 5,
      timestamp: new Date("Mar 12, 2020"),
      reviewText: "What a great place.",
    },
  ],
};
