function randomNum(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function randomSize(arr) {
  return Math.floor(Math.random() * (arr.length - 1));
}

const address = {
  addrs: [
    "관악구 호암로 ",
    "강남구 테헤란로 ",
    "성북구 안암로 ",
    "중구 세종대로 ",
  ],
  generate: () => {
    console.log(address.addrs);
    return (
      "서울 특별시 " +
      address.addrs[randomSize(address.addrs)] +
      randomNum(1, 100)
    );
  },
};

const facilities = {
  lists: [
    "Hot drinks",
    "Food",
    "low speed wifi",
    "Premium wifi",
    "Restroom",
    "Ah-Ah",
  ],
  generate: () => {
    let facilityQueue = JSON.parse(JSON.stringify(facilities.lists));
    let selected = [];
    for (let i = 0; i < randomNum(2, facilities.lists.length); i++) {
      selected.push(facilityQueue.pop(randomSize(facilityQueue)));
      console.log(selected);
    }
    return selected;
  },
};

const reviewText = {
  subject: ["this place", "wifi", "Hot Drink", "coffee"],
  verb: ["is"],
  complement: ["good", "great", "bad", "too slow"],

  generate: () => {
    let text = "";
    text += reviewText.subject[randomSize(reviewText.subject)] + " ";
    text += reviewText.verb[randomSize(reviewText.verb)] + " ";
    text += reviewText.complement[randomSize(reviewText.complement)];
    return text;
  },
};

function nameGenerator() {
  let name = "";
  for (let i = 0; i < randomNum(3, 10); i++) {
    name += String.fromCharCode(randomNum(97, 122));
  }
  return name;
}

const generateLocationData = () => {
  var LocationData = {
    name: nameGenerator(),
    address: address.generate(),
    rating: randomNum(1, 5),
    facilities: facilities.generate(),
    coords: [
      parseFloat("127." + randomNum(1000, 9999)),
      parseFloat("37." + randomNum(1000, 9999)),
    ],
    openingTimes: [
      {
        days: "Monday - Friday",
        opening: randomNum(6, 10) + ":00am",
        closing: randomNum(6, 10) + ":00pm",
        closed: false,
      },
      {
        days: "Saturday",
        opening: randomNum(8, 10) + ":00am",
        closing: randomNum(5, 8) + ":00pm",
        closed: false,
      },
      {
        days: "Sunday",
        closed: true,
      },
    ],
    reviews: [
      {
        author: nameGenerator(),
        rating: randomNum(1, 5),
        timestamp: Date.now(),
        reviewText: reviewText.generate(),
      },
    ],
  };
  return LocationData;
};

module.exports = {
  generateLocationData: generateLocationData,
};
